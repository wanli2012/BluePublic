//
//  HXPhotoCustomNavigationBar.h
//  微博照片选择
//
//  Created by 洪欣 on 2017/9/22.
//  Copyright © 2017年 洪欣. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface HXPhotoCustomNavigationBar : UINavigationBar

@end
