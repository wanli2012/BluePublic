//
//  HXCustomCollectionReusableView.h
//  微博照片选择
//
//  Created by 洪欣 on 2017/11/8.
//  Copyright © 2017年 洪欣. All rights reserved.
//

#import <UIKit/UIKit.h>

#ifdef __IPHONE_11_0
@interface HXCustomLayer : CALayer

@end
#endif


@interface HXCustomCollectionReusableView : UICollectionReusableView

@end
